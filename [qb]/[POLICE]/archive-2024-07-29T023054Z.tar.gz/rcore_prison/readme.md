# rcore_prison

**Follow the installation guide in documentation link below, please!**

## **Documentation**
If you have any questions, please take a look into our rich documentation containing all features, settings and more!

**📚 Documentation https://documentation.rcore.cz/paid-resources/rcore_prison** <br/><br/>

If you still have any questions after reading documentation, feel free to reach out to us on our discord!


## **Where to change the Prisob job reward?**

1. Navigate to the rcore_prison/data/presets/yourPrisonMap.lua
2. Search through the file for jobs.
3. Look for jobs.reward and adjust it as you need.
4. Have fun!

📧 https://discord.gg/F28PfsY

***
