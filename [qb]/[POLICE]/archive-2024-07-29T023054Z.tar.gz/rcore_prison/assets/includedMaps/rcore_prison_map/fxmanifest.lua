--[[ FX Information ]]--
fx_version   'cerulean'
lua54        'yes'
game         'gta5'

--[[ Resource Information ]]--
name         'rcore_prison_map'
author       'K4MB1'
version      '1.0'
description  'With permission to be distributed along with rcore_prison'

this_is_a_map "yes"
