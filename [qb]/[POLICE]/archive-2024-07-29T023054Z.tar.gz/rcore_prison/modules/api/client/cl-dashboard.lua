function OpenDashboard()
    ExecuteCommand('jailcp')
end

provideExport('OpenDashboard', 'rcore_prison', OpenDashboard)

