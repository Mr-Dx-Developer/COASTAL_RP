INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES ('sprunk', 'Sprunk', '1', '0', '1');
INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES ('ecola_light', 'Ecola light', '1', '0', '1');
INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES ('coffee', 'Coffee', '1', '0', '1');
INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES ('cigs_69brand', '69 Brand', '1', '0', '1');
INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES ('cigs_cardiaque', 'Cardiaque', '1', '0', '1');
INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES ('cigs_debonaireblue', 'Debonaire Blue', '1', '0', '1');
INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES ('cigs_debonairegreen', 'Debonaire Green', '1', '0', '1');
INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES ('cigs_redwood', 'Red Wood', '1', '0', '1');
INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES ('sludgie', 'Sludgie', '1', '0', '1');