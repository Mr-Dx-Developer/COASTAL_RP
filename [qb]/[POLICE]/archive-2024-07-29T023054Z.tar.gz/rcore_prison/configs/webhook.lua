Logs = {
    Type = 'discord',
    Hook = 'https://discord.com/api/webhooks/1255878716073185300/v5nawxYo59ahzCQU_Hs52N8-nATvj-E7ucg68kvy86uZ0z_-lgHXljrgoAjNpJAp39zc'
}